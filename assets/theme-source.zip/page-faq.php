<?php
/** Template Name: FAQ */
$ats_site_body_class = 'faq-page';
get_header();
?>

<main id="main-content">
        <section class="page-intro">
			<div class="container">
				<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">FAQ</span>よくあるご質問</h2>
			</div>
		</section>
	<div class="container">
        <?php get_template_part('template-parts/ats-breadcrumb'); ?>
    </div>
        <section class="faq-page-content bottom-gradient" aria-label="よくあるご質問一覧">
            <div class="container">
				<div class="enri-faq-cntr">
					<?php
					
					$faqs = SCF::get( 'faq' );

					if ( ! empty( $faqs ) ) :
						foreach ( $faqs as $faq ) :
							if ( empty( $faq['faq_title'] ) ) { continue; }
							?>
							<div class="enri-faq-box">
								<div class="enri-faq-q">
									<p><?php echo esc_html( $faq['faq_title'] ); ?></p>
								</div>
								<div class="enri-faq-ans">
									<?php echo wp_kses_post( $faq['faq_ct'] ?? '' ); ?>
								</div>
							</div>
							<?php
						endforeach;
					endif;
					?>
				</div>
			</div>
        </section>

        <!-- cta banner -->
        <div class="cta-modal-call">
             <section class="footer-cta" data-cta="cta-data"><?php get_template_part('template-parts/ats-cta'); ?></section>
        </div>
        <!-- cta banner end -->

        <!-- contact modal box  -->
        <section class="modal-popup" data-contact="contact-show"><?php get_template_part('template-parts/ats-contact'); ?></section>
        <!-- contact modal box end -->
    </main>
<?php get_footer(); ?>
