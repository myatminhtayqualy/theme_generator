<?php
/**
 * Template Name: TOP
 */
$ats_site_body_class = 'top-body';
get_header();
?>

<main id="main-content">
		<!-- MV section -->
		<section class="mv-sect">
			<div class="mv-container">
				<div class="mv-grid">
					<div class="mv-content-blk">
						<div>
							<div class="mv-messages">
								<div class="mv-msg">育成就労制度 対応</div>
								<div class="mv-msg">特定技能制度 対応</div>
							</div>
							<div class="mv-ttl">その<span class="biggest-span">1</span><span class="smallest-span">人</span>が、<br>御社の<span class="medium-span">戦力</span>になる。</div>
						</div>

						<p class="mv-para">ATS事業協同組合は監理支援機関申請済み。<br class="tablet"><span class="fcolor-blue">「育成就労の認定申請」ができる</span>組合です。<br>制度の切り替わりで内容の把握が難しい<br class="tablet">「育成就労」制度を熟知しており、<br>スムースな制度導入・切り替えのお手伝いが可能です。</p>

						<a href="/contact/" class="cmn-btn">無料相談を申し込む</a>
					</div>

					<picture class="mv-img">
						<source srcset="<?php echo esc_url( get_template_directory_uri() . '/assets/img/mv_img.webp' ); ?>" type="image/webp">
						<img width="711" height="517" src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/mv_img.png' ); ?>" alt="その1人が、御社の戦力になるの画像">
					</picture>

					<?php
					// Circle 1 Data
					$c1_ttl  = SCF::get('mv_circle_one_ttl');
					$c1_num  = SCF::get('mv_circle_one_number');
					$c1_unit = SCF::get('mv_circle_one_unit');
					$c1_txt  = SCF::get('mv_circle_one_txt');

					// Circle 2 Data
					$c2_ttl  = SCF::get('mv_circle_two_ttl');
					$c2_num  = SCF::get('mv_circle_two_number');
					$c2_unit = SCF::get('mv_circle_two_unit');
					$c2_txt  = SCF::get('mv_circle_two_txt');

					// Circle 3 Data
					$c3_ttl     = SCF::get('mv_circle_three_ttl');
					$c3_num1    = SCF::get('mv_circle_three_number');
					$c3_num2    = SCF::get('mv_circle_three_number_two');
					$c3_unit    = SCF::get('mv_circle_three_unit'); 
					$c3_txt     = SCF::get('mv_circle_three_txt');
					?>

					<div class="mv-circles">
						
						<div class="mv-circle">
							<div class="mv-circle-ttl"><?php echo esc_html(!empty($c1_ttl) ? $c1_ttl : '累計支援外国人'); ?></div>
							<div class="mv-cirlce-num">
								<?php echo esc_html(!empty($c1_num) ? $c1_num : '513'); ?><span><?php echo esc_html(!empty($c1_unit) ? $c1_unit : '人'); ?></span>
							</div>
							<div class="mv-circle-span"><?php echo esc_html(!empty($c1_txt) ? $c1_txt : '※2026年9月現在'); ?></div>
						</div>

						
						<div class="mv-circle">
							<div class="mv-circle-ttl"><?php echo esc_html(!empty($c2_ttl) ? $c2_ttl : '受入企業数'); ?></div>
							<div class="mv-cirlce-num">
								<?php echo esc_html(!empty($c2_num) ? $c2_num : '24'); ?><span><?php echo esc_html(!empty($c2_unit) ? $c2_unit : '社'); ?></span>
							</div>
							<div class="mv-circle-span"><?php echo esc_html(!empty($c2_txt) ? $c2_txt : '現在受入中の企業数'); ?></div>
						</div>

						
						<div class="mv-circle">
							<div class="mv-circle-ttl"><?php echo esc_html(!empty($c3_ttl) ? $c3_ttl : '取扱国'); ?></div>
							<div class="mv-cirlce-num">
								<?php echo esc_html(!empty($c3_num1) ? $c3_num1 : '4'); ?> 
								<span class="lil-bigger"><?php echo esc_html(!empty($c3_unit) ? $c3_unit : '+'); ?></span> 
								<?php echo esc_html(!empty($c3_num2) ? $c3_num2 : '4'); ?>
							</div>
							<div class="mv-circle-span">
								<?php echo nl2br(esc_html(!empty($c3_txt) ? $c3_txt : "実績4カ国＋\n対応予定4カ国")); ?>
							</div>
						</div>
					</div>

				</div>
			</div>
		</section>
		<!-- MV section end -->
		
		<section class="top-banner-sect">
			<div class="container">
				<div class="sub-container">
					<!-- banner -->
					<section id="banner">
						<!-- banner -->
						<section id="banner">
							<?php get_template_part('template-parts/ats-banner'); ?>
						</section>
						<!-- banner end -->
					</section>
					<!-- banner end -->

				</div>
			</div>
		</section>
		
		<?php
		$ats_news_query = new WP_Query(
			array(
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'posts_per_page'      => 3,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);

		
		if ( $ats_news_query->have_posts() ) :
		?>
		<!-- news -->
		<div class="news-sect" id="news">
			<div class="container">
				<div class="sub-container">
					<h2 class="cmn-ttl">
						<p class="cmn-ttl-en">News</p>
						<p class="cmn-ttl-jp">お知らせ</p>
					</h2>
					<div class="top-news">
						<?php
						while ( $ats_news_query->have_posts() ) :
							$ats_news_query->the_post();
							?>
							<a href="<?php echo esc_url( get_the_permalink() ); ?>" class="news-item">
								<span class="news-date"><?php echo esc_html( get_the_date( 'Y.m.d' ) ); ?></span>
								<?php if ( 'post' === get_post_type() ) : ?>
									<span class="news-noti">お知らせ</span>
								<?php endif; ?>
								<span class="news-content"><?php echo esc_html( get_the_title() ); ?></span>
							</a>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
					<a href="<?php echo esc_url( home_url( '/news/' ) ); ?>" class="cmn-btn news-cmn-btn">お知らせ一覧</a>
				</div>
			</div>
		</div>
		<!-- news end -->
		<?php endif; ?>

		<!-- programs section -->
		<section class="prog-sect" id="programs">
			<div class="container">

				<h2 class="cmn-ttl">
					<p class="cmn-ttl-en">Programs</p>
					<p class="cmn-ttl-jp">
						貴社に合う受け入れ方法を、<br>
						ご提案いたします。
					</p>
				</h2>

				<div class="prog-grid">

					<?php
					// SCF Group
					$programs = SCF::get('programs');
					?>

					<?php if (!empty($programs)) : ?>

						<?php foreach ($programs as $program) : ?>

							<?php
							$program_label       = $program['program_label'] ?? '';
							$program_title       = $program['program_title'] ?? '';
							$program_description = $program['program_description'] ?? '';
							$program_link        = $program['program_link'] ?? '';
							$program_link_text   = $program['program_link_text'] ?? '';
							$program_is_new      = $program['program_is_new'] ?? false;
							?>

							<div class="prog-card">

								<?php if ($program_label) : ?>
									<div class="card-label">
										<?php echo esc_html($program_label); ?>
									</div>
								<?php endif; ?>

								<?php if ($program_title) : ?>
									<h3 class="prog-card-ttl <?php echo $program_is_new ? 'new' : ''; ?>">
										<?php echo esc_html($program_title); ?>
									</h3>
								<?php endif; ?>

								<?php if ($program_description) : ?>
									<div class="prog-card-para">
										<?php echo wp_kses_post($program_description); ?>
									</div>
								<?php endif; ?>

								<?php if ($program_link && $program_link_text) : ?>
									<a
										href="<?php echo esc_url($program_link); ?>"
										class="cmn-btn"
									>
										<?php echo esc_html($program_link_text); ?>
									</a>
								<?php endif; ?>

							</div>

						<?php endforeach; ?>

					<?php endif; ?>

				</div>
			</div>
		</section>
		<!-- programs section end -->

		<!-- cta banner -->
		<div class="container cta-modal-call">
			<section class="mb-add" data-cta="cta-data">
				<!-- <?php get_template_part( 'template-parts/ats-cta' ); ?> -->
			</section>
		</div>
		<!-- cta banner end -->

		<!-- why section -->
		<section class="ats-why" id="about">
			<div class="container">

				<h2 class="cmn-ttl">
					<p class="cmn-ttl-en">Why ATS</p>
					<p class="cmn-ttl-jp">
						選ばれる<br>
						「4つの柱」がございます。
					</p>
				</h2>

				<div class="why-cards">

					<?php
					// SCF Group
					$why_ats = SCF::get('why_ats');
					?>

					<?php if (!empty($why_ats)) : ?>

						<?php
						$counter = 1;
						?>

						<?php foreach ($why_ats as $why) : ?>

							<?php
							$why_title       = $why['why_ats_title'] ?? '';
							$why_description = $why['why_ats_description'] ?? '';
							?>

							<div class="why-card">

								<div class="why-number">
									<?php echo esc_html(sprintf('%02d', $counter)); ?>
								</div>

								<?php if ($why_title) : ?>
									<h3 class="why-ttl">
										<?php echo esc_html($why_title); ?>
									</h3>
								<?php endif; ?>

								<?php if ($why_description) : ?>
									<div class="why-para">
										<?php echo wp_kses_post($why_description); ?>
									</div>
								<?php endif; ?>

							</div>

							<?php $counter++; ?>

						<?php endforeach; ?>

					<?php endif; ?>

				</div>

				<a href="/about/" class="cmn-btn why-btn">ATS事業協同組合について</a>

			</div>
		</section>
		<!-- why section end -->

		<section class="record-bg">
			<!-- track record section -->
			<div class="ats-track-rc">
				<div class="container">
					<?php 
						$record_year = SCF::get('track_record_year');
						$record_people = SCF::get('people_count');
					?>
					<h2 class="cmn-ttl">
						<p class="cmn-ttl-en">Track Record</p>
						<p class="cmn-ttl-jp">監理・支援している外国人材数は<br><?php echo esc_html($record_year); ?>年で<?php echo esc_html($record_people); ?>名超になりました。</p>
					</h2>

					<?php 
					$record_desc = SCF::get('track_record_description');
					?>
					<?php if (!empty($record_desc)) : ?>
						<div class="cmn-para-ttl record-ttl">
							<?php echo nl2br(wp_kses_post($record_desc)); ?>
						</div>
					<?php endif; ?>

					<?php 
					// 2. Repeat Group: track_recordss
					$track_records = SCF::get('track_records');
					?>
					<?php if (!empty($track_records)) : ?>
						<div class="record-cards">
							<?php foreach ($track_records as $index => $record) : 
								$card_label = $record['track_record_label'] ?? '';
								$card_img_id = $record['track_record_img'] ?? '';
								
								$card_class = ($index === 0) ? 'record-card-main' : 'record-card-side';
							?>
								<div class="record-card <?php echo esc_attr($card_class); ?>">
									
									<?php if (!empty($card_label)) : ?>
										<div class="card-label">
											<?php echo esc_html($card_label); ?>
										</div>
									<?php endif; ?>

									<div class="record-card-image">
										<?php 
										if (!empty($card_img_id)) {
											echo wp_get_attachment_image($card_img_id, 'full', false, array(
												'alt' => !empty($card_label) ? esc_attr($card_label) . 'の画像' : '実績画像'
											));
										}
										?>
									</div>

								</div>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

				</div>
			</div>
			<!-- track record section end -->

			<!-- Countries section -->
			<div class="countries-section">
				<div class="container">
					<h2 class="cmn-ttl">
						<p class="cmn-ttl-en">Countries</p>
						<p class="cmn-ttl-jp">
							特定の国に依存しない、<br>7カ国の受け入れ体制へ。
						</p>
					</h2>

					<?php
					$countries = SCF::get('countries');
					?>

					<?php if (!empty($countries)) : ?>

						<div class="countries-cards">

							<?php foreach ($countries as $index => $item) : ?>
								

								<div class="countries-card<?php echo ($index === 0) ? ' thin' : ''; ?>">

									<div class="card-label<?php echo ($index > 0) ? ' green' : ''; ?>">
										<?php echo esc_html($item['countries_label'] ?? ''); ?>
									</div>

									<h3 class="countries-card-ttl">
										<?php echo nl2br(esc_html($item['countries_title'] ?? '')); ?>
									</h3>

									<p class="countries-card-para">
										<?php echo nl2br(esc_html($item['countries_desc'] ?? '')); ?>
									</p>

								</div>

							<?php endforeach; ?>

						</div>

					<?php endif; ?>

				</div>
			</div>
			<!-- Countries section end -->
		</section>
		

		<!-- focus section -->
        <section class="ats-focus">
			<div class="container">
				<h2 class="cmn-ttl">
					<p class="cmn-ttl-en">Focus</p>
					<p class="cmn-ttl-jp">制度が変わる、その前に。</p>
				</h2>

				<div class="cmn-para-ttl">
                    <?php
                    $intro = SCF::get('focus_intro');
                    echo wp_kses_post( $intro );
                    ?>
                </div>

				<div class="focus-boxes">
                    <?php
                    $focuses = SCF::get('focus');
                    if ( ! empty( $focuses ) ) :
                        foreach ( $focuses as $index => $focus ) :
                            if ( empty( $focus['focus_title'] ) ) { continue; }
                            ?>
                            <div class="focus-box <?php echo 0 === $index % 2 ? 'foward-arr' : 'backward-arr'; ?>">
                                <div class="focus-date"><?php echo esc_html( $focus['focus_date'] ?? '' ); ?></div>
                                <h3 class="focus-ttl"><?php echo wp_kses_post( $focus['focus_title'] ?? '' ); ?></h3>
                                <div class="focus-para"><?php echo wp_kses_post( $focus['focus_ct'] ?? '' ); ?></div>
                            </div>
                            <?php
                        endforeach;
                    endif;
                    ?>
                </div>

                <!-- cta banner -->
                 <div class="cta-modal-call">
                     <section class="mt-add" data-cta="cta-data">
                         <?php get_template_part( 'template-parts/ats-cta' ); ?>
                     </section>
                 </div>
				<!-- cta banner end -->

			</div>
		</section>
        <!-- focus section end -->

        <!-- flow section -->
        <section class="flow-section">
            <div class="container">
                <h2 class="cmn-ttl">
                    <span class="cmn-ttl-en">Flow</span>
                    <span class="cmn-ttl-jp">受け入れまでの流れ</span>
                </h2>
                <div class="cmn-para-ttl flow-intro">
                    <?php
                    $intro = SCF::get('flow_intro');
                    echo wp_kses_post( $intro );
                    ?>
                </div>

                <ol class="flow-steps">
                    <?php
                    $flows = SCF::get('flow');
                    if ( ! empty( $flows ) ) :
                        $step = 0;
                        foreach ( $flows as $flow ) :
                            if ( empty( $flow['flow_title'] ) ) { continue; }
                            ++$step;
                            ?>
                            <li class="flow-step">
                                <span class="flow-step-number"><?php echo esc_html( sprintf( '%02d', $step ) ); ?></span>
                                <h3 class="flow-step-title"><?php echo nl2br(esc_html( $flow['flow_title'] ?? '' )) ?></h3>
                                <p class="flow-step-period"><?php echo esc_html( $flow['flow_period'] ?? '' ); ?></p>
                                <div class="flow-step-description"><?php echo wp_kses_post( $flow['flow_ct'] ?? '' ); ?></div>
                            </li>
                            <?php
                        endforeach;
                    endif;
                    ?>
                </ol>
            </div>
        </section>
        <!-- flow section end -->

        <!-- voice section -->
        <section class="voice-section">
            <div class="container voice-container">
                <h2 class="cmn-ttl">
                    <span class="cmn-ttl-en">Voice</span>
                    <span class="cmn-ttl-jp">受け入れ企業の声</span>
                </h2>
                
            </div>
			<div class="voice-slider">
                <?php
                $voices = SCF::get('voice');
                if ( ! empty( $voices ) ) :
                    foreach ( $voices as $voice ) :
                        if ( empty( $voice['voice_comment'] ) ) { continue; }
                        ?>
                        <article class="voice-slide">
                            <div class="voice-comment"><?php echo wp_kses_post( $voice['voice_comment'] ?? '' ); ?></div>
                            <div class="voice-company">
                                <?php
                                $voice_image = absint( $voice['voice_image'] ?? 0 );
                                if ( $voice_image ) {
                                    echo wp_get_attachment_image( $voice_image, 'full', false, array(
                                        'class' => 'voice-person',
                                        'alt'   => $voice['voice_image_alt'] ?? '',
                                    ) );
                                }
                                ?>
                                <div>
                                    <h3><?php echo esc_html( $voice['voice_company'] ?? '' ); ?></h3>
                                    <p><?php echo wp_kses_post( $voice['voice_detail'] ?? '' ); ?></p>
                                </div>
                            </div>
                        </article>
                        <?php
                    endforeach;
                endif;
                ?>
            </div>
        </section>
        <!-- voice section end -->

        <!-- faq section -->
        <section class="sec-faq enriku-gray-bg" id="faqs">
			<div class="enriku-container container">
				<h2 class="cmn-ttl">
					<span class="cmn-ttl-en">FAQ</span>
					<span class="cmn-ttl-jp">よくあるご質問</span>
				</h2>
				<div class="enri-faq-cntr">
					<?php
					
					$faq_page = get_page_by_path( 'faq', OBJECT, 'page' );
					$faq_page_id = $faq_page ? $faq_page->ID : 9;

				
					$faqs = $faq_page_id ? SCF::get( 'faq', $faq_page_id ) : array();

					if ( ! empty( $faqs ) ) :
						foreach ( $faqs as $faq ) :
							if ( empty( $faq['faq_title'] ) ) { continue; }

							
							$show_top = $faq['faq_show_top'] ?? '';
							$is_checked = false;

							if ( is_array( $show_top ) ) {
								$is_checked = ! empty( array_filter( $show_top ) );
							} else {
								$is_checked = ! empty( $show_top );
							}

							
							if ( ! $is_checked ) { continue; }
							?>
							<div class="enri-faq-box">
								<div class="enri-faq-q">
									<p><?php echo wp_kses_post( $faq['faq_title'] ?? '' ); ?></p>
								</div>
								<div class="enri-faq-ans">
									<?php echo wp_kses_post( $faq['faq_ct'] ?? '' ); ?>
								</div>
							</div>
							<?php
						endforeach;
					endif;
					?>
				</div>
			</div>
		</section>
        <!-- faq section end -->


		<!-- cta banner -->
		<div class="cta-modal-call">
			 <section class="footer-cta" data-cta="cta-data">
				 <?php get_template_part( 'template-parts/ats-cta' ); ?>
			 </section>
		</div>
		<!-- cta banner end -->

		<!-- contact modal box  -->
		<section data-contact="contact-show" class="modal-popup">
			<?php get_template_part( 'template-parts/ats-contact' ); ?>
		</section>
		<!-- contact modal box end -->
	</main>

<?php get_footer(); ?>
