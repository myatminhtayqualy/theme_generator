
<?php
// Current program page slug
$current_slug = get_post_field('post_name', get_queried_object_id());

// Program data
$programs = [
    'esd' => [
        'title' => '育成就労',
        'description' => '人手不足の産業分野において、原則3年間の就労を通じて人材育成をし、人材を確保する制度です。ATS事業協同組合は監理支援機関として許認可申請済みで、育成就労の認定申請ができる状況になっています。',
    ],
    'ssw' => [
        'title' => '特定技能',
        'description' => '試験合格者を即戦力として受け入れる制度です。1号は通算5年、2号は上限がありません。ATS事業協同組合は登録支援機関（2020年7月登録）として、生活・就労の支援を担います。',
    ],
    'tit' => [
        'title' => '技能実習',
        'description' => '2027年3月末までの申請分が対象です。88職種165作業。在籍中の実習生は、計画の満了まで現在の在留資格のまま継続できます。育成就労への切り替えもご相談ください。',
    ],
];

// Stop if this is not one of the program pages
if (!isset($programs[$current_slug])) {
    return;
}

$current_program = $programs[$current_slug];
?>

<section class="prog-sect other-programs reduce-padding">
    <div class="container">

        <h3 class="cmn-ttl">
            <p class="cmn-ttl-jp">他の制度を見る</p>
        </h3>

        <div class="cmn-para-ttl record-ttl">
            <p>
                <?php echo esc_html($current_program['title']); ?>以外の制度もご相談いただけます。<br class="sp">
                どの制度が自社に合うか決まっていない段階からでも構いません。
            </p>
        </div>

        <div class="prog-grid">

            <?php foreach ($programs as $slug => $program) : ?>

                <?php
                // Do not display the current program
                if ($slug === $current_slug) {
                    continue;
                }

                // Get the program page URL
                $program_page = get_page_by_path($slug);
                $program_url = $program_page
                    ? get_permalink($program_page->ID)
                    : home_url('/' . $slug . '/');
                ?>

                <div class="prog-card other">

                    <h4 class="prog-card-ttl">
                        <?php echo esc_html($program['title']); ?>
                    </h4>

                    <p class="prog-card-para">
                        <?php echo esc_html($program['description']); ?>
                    </p>

                    <a href="<?php echo esc_url($program_url); ?>"
                       class="cmn-btn">
                        <?php echo esc_html($program['title']); ?>について
                    </a>

                </div>

            <?php endforeach; ?>

        </div>
    </div>
</section>
