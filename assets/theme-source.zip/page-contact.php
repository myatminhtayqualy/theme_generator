<?php

/** Template Name: Contact */
$ats_site_body_class = 'contact-page';
get_header();
?>
<main id="main-content">
	<section class="page-intro">
		<div class="container">
			<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">Contact</span>お問い合わせ</h2>
		</div>
	</section>
	<div class="container">
        <?php get_template_part('template-parts/ats-breadcrumb'); ?>
    </div>
	<section class="faq-page-content bottom-gradient" aria-label="よくあるご質問一覧">
		<div class="container">
			<div class="form-heading">
				<p class="heading fz-14-sp fz-n-sp">下記の必須項目をご入力ください。</p>
				<p class="sub-heading fz-14-sp fz-n-sp">※は必須項目です。</p>

				<?php echo do_shortcode('[contact-form-7 id="856f64e" title="ATS Contact From"]'); ?>
			</div>

		</div>
	</section>
</main>
<?php get_footer(); ?>