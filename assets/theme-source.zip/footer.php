<footer id="footer">
	<div class="footer-container">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-logo">
			<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/common/ats_logo.png' ); ?>" alt="ATS事業協同組合">
		</a>

		<nav class="footer-nav" aria-label="フッターナビゲーション">
			<ul>
				<li><a href="<?php echo esc_url( home_url( '/esd/' ) ); ?>">育成就労</a></li>
				<li><a href="<?php echo esc_url( home_url( '/ssw/' ) ); ?>">特定技能</a></li>
				<li><a href="<?php echo esc_url( home_url( '/tit/' ) ); ?>">技能実習</a></li>
				<li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>">ATSについて</a></li>
				<li><a href="<?php echo esc_url( home_url( '/news/' ) ); ?>">お知らせ</a></li>
				<li><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>">よくある質問</a></li>
			</ul>
		</nav>

		<div class="footer-details">
			<address class="footer-address">
				〒112-0002<br>
				東京都文京区小石川2-1-13<br>
				後楽園ビューハイツ205<br>
				<a href="tel:0368696161">TEL 03-6869-6161</a>
			</address>
			<p class="footer-licenses">
				一般監理事業（優良）許可 2019.11.08／2024.08.30<br>
				登録支援機関 登録 2020.07.16<br>
				監理支援機関 許認可申請済み
			</p>
		</div>

		<div class="footer-legal">
			<ul class="footer-policy-links">
				<li><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">プライバシーポリシー</a></li>
				<li><a href="<?php echo esc_url( get_template_directory_uri() . '/assets/pdf/監理団体.pdf' ); ?>" target="_blank" rel="noopener noreferrer">監理団体の業務の運営に係る規定</a></li>
			</ul>
			<small class="footer-copyright">© ATS事業協同組合</small>
		</div>
	</div>
</footer>

<script src="<?php echo esc_url( get_template_directory_uri() . '/assets/js/jquery-3.7.1.min.js' ); ?>"></script>
<script src="<?php echo esc_url( get_template_directory_uri() . '/assets/js/jquery.matchHeight.js' ); ?>"></script>
<script src="<?php echo esc_url( get_template_directory_uri() . '/assets/slick/slick.min.js' ); ?>"></script>
<script src="<?php echo esc_url( get_template_directory_uri() . '/assets/js/common.js' ); ?>"></script>
<?php wp_footer(); ?>
</body>
</html>
