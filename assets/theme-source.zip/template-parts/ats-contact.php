<div class="overlay" aria-hidden="true">
	<div id="pop-up" class="popup">
		<button class="exit-popup" type="button" aria-label="閉じる"></button>
		<div class="popup-container">
			<h2 class="cmn-ttl">
				<p class="cmn-ttl-en">Contact</p>
				<p class="cmn-ttl-jp">お問い合わせ</p>
			</h2>
			<div class="cmn-para-ttl">
				<p>「自分の会社に合っている制度を知りたい」<br>「外国人材を採用したいが、<br class="sp">何から始めればいいかわからない」</p>
				<p class="popup-big-para">まずは気軽にご相談ください。</p>
			</div>
			<div class="popup-grid">
				<div class="popup-contact">
					<h3 class="popup-contact-ttl">お電話でのお問い合わせ</h3>
					<a href="tel:03-6869-6161" class="popup-phone-btn">03-6869-6161</a>
				</div>
				<div class="popup-contact">
					<h3 class="popup-contact-ttl">メールでのお問い合わせ</h3>
					<a href="mailto:info@atsjigyo.com" class="popup-mail-btn">メールを送信する</a>
				</div>
			</div>
		</div>
	</div>
</div>
