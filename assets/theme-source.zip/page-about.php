<?php

/**
 * 
 * Template Name: About
 * 
 */
get_header();
?>

<main id="main-content">
	<section class="page-intro about-intro">
		<div class="container">
			<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">About</span>ATS事業協同組合について</h2>
		</div>
	</section>
	<div class="container">
        <?php get_template_part('template-parts/ats-breadcrumb'); ?>
    </div>
	<section class="philosophy-sec">
		<div class="container">
			<h3 class="cmn-ttl cmn-ttl-jp">
				ATS事業協同組合の運営理念
			</h3>
			<div class="cmn-para-ttl philo-ttl">
				<p>私たちATS事業協同組合は以下の経営理念に基き、</p>
				<p>実施者及び実習生の為に監理団体を運営して<br class="sp">いくことをお約束いたします。</p>
			</div>

			<?php
			$philosophy_lists = SCF::get('philosophy_lists');
			?>
			<div class="sub-container">
				<div class="philo-cont">
					<ul class="philo-list">
						<?php foreach ($philosophy_lists as $philosophy) : ?>
							<li class="philo-listitem"><?php echo esc_html($philosophy['philosophy_list']); ?></li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		</div>
	</section>

	<section class="overview-sec info-section">
		<div class="container">
			<h3 class="cmn-ttl cmn-ttl-jp">組織概要</h3>

			<?php 
				$overviews = SCF::get('overviews');
			?>
			<ul class="info-block">

				<?php foreach ($overviews as $overview) : ?>
					<li class="info-list">
						<div class="info-left">
							<p><?php echo nl2br(esc_html($overview['overviews_label'])); ?></p>
						</div>
						<div class="info-right">
							<p><?php echo wp_kses_post($overview['overviews_content']); ?></p>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>

	<section class="map-sec bottom-gradient">
		<div class="container">
			<h3 class="cmn-ttl cmn-ttl-jp">アクセス</h3>
			<h4 class="map-ttl">ATS事業協同組合</h4>
			<div class="cmn-para-ttl map-para-ttl">
				<p>〒112-0002</p>
				<p>東京都文京区小石川2丁目1-13 後楽園ビューハイツ205</p>
			</div>
			<div class="map-img-cont">
				<picture>
					<source srcset="<?php echo esc_url(get_template_directory_uri() . '/assets/img/map.webp'); ?>" type="image/webp">

					<img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/map.png'); ?>" alt="google_mapの画像">
				</picture>
			</div>
			<a class="cmn-btn map-btn" href="https://www.google.com/maps/search/?api=1&amp;query=%e6%9d%b1%e4%ba%ac%e9%83%bd%e6%96%87%e4%ba%ac%e5%8c%ba%e5%b0%8f%e7%9f%b3%e5%b7%9d2%e4%b8%81%e7%9b%ae1-13&amp;query_place_id=" target="_blank">Google Maps</a>
		</div>
	</section>

	<!-- cta banner -->
	<div class="cta-modal-call">
		<section class="footer-cta" data-cta="cta-data">
			<?php get_template_part('template-parts/ats-cta'); ?>
		</section>
	</div>
	<!-- cta banner end -->

	<!-- contact modal box  -->
	<section class="modal-popup" data-contact="contact-show">
		<?php get_template_part('template-parts/ats-contact'); ?>
	</section>
	<!-- contact modal box end -->
</main>

<?php get_footer(); ?>