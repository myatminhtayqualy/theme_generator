<?php
/**
 * The template for displaying 404 pages (not found)
 */
get_header();
?>

<main id="main-content">
    <section class="page-intro">
        <div class="container">
            <h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">404 Not Found</span>ページが見つかりません</h2>
        </div>
    </section>

    <section class="faq-page-content bottom-gradient" aria-label="404 エラー">
        <div class="container">
            <div class="form-heading" style="text-align: center;">
                <p class="heading fz-14-sp fz-n-sp" style="margin-bottom: 20px;">
                    お探しのページは見つかりませんでした。
                </p>
                <p class="sub-heading fz-14-sp fz-n-sp" style="line-height: 1.8; margin-bottom: 40px;">
                    アクセスしようとしたページは、削除されたか、名前が変更されたか、<br class="pc-only">
                    あるいは一時的に利用できない可能性があります。<br>
                    URLに間違いがないか再度ご確認ください。
                </p>

				<div class="single-back-btn-wrap">
					<a class="news-single-back cmn-btn" href="<?php echo esc_url(home_url('/')); ?>">トップページへ戻る</a>
				</div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>