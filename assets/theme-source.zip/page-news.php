<?php

/**
 * Template Name: News
 */
$ats_site_body_class = '';
get_header();
?>

<main id="main-content">
	<section class="page-intro">
		<div class="container">
			<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">News</span>お知らせ</h2>
		</div>
	</section>
	<div class="container">
        <?php get_template_part('template-parts/ats-breadcrumb'); ?>
    </div>

	<section class="news-banner-sect">
		<div class="container">
			<div class="sub-container">
				<!-- banner -->
				<section id="banner">
					<?php get_template_part('template-parts/ats-banner'); ?>
				</section>
				<!-- banner end -->
			</div>
		</div>
	</section>

	<section class="news-sect news-page bottom-gradient">
		<div class="container">
			<div class="sub-container">
				<div class="top-news">
					<?php
					$ats_news_current_page = max(1, absint(get_query_var('paged')), absint(get_query_var('page')));
					$ats_news_query        = new WP_Query(
						array(
							'post_type'           => 'post',
							'post_status'         => 'publish',
							'posts_per_page'      => 10,
							'paged'               => $ats_news_current_page,
							'ignore_sticky_posts' => true,
						)
					);

					if ($ats_news_query->have_posts()) :
						while ($ats_news_query->have_posts()) :
							$ats_news_query->the_post();
					?>
							<a href="<?php echo esc_url(get_the_permalink()); ?>" class="news-item">
								<span class="news-date"><?php echo esc_html(get_the_date('Y.m.d')); ?></span>
								<?php if ('post' === get_post_type()) : ?>
									<span class="news-noti">お知らせ</span>
								<?php endif; ?>
								<span class="news-content"><?php echo esc_html(get_the_title()); ?></span>
							</a>
						<?php
						endwhile;
						?>
				</div>

				<?php
						$ats_news_pagination = paginate_links(
							array(
								'current'   => $ats_news_current_page,
								'total'     => $ats_news_query->max_num_pages,
								'type'      => 'array',
								'prev_text' => '',
								'next_text' => '',
							)
						);

						if ($ats_news_pagination) :
				?>
					<nav class="pagination" aria-label="お知らせページ">
						<div class="wp-pagenavi">
							<?php
							foreach ($ats_news_pagination as $ats_news_page_link) {
								$ats_news_page_link = str_replace('page-numbers current', 'page current', $ats_news_page_link);
								$ats_news_page_link = str_replace('page-numbers', 'page', $ats_news_page_link);
								$ats_news_page_link = str_replace('class="prev page"', 'class="previouspostslink"', $ats_news_page_link);
								$ats_news_page_link = str_replace('class="next page"', 'class="nextpostslink"', $ats_news_page_link);
								echo wp_kses_post($ats_news_page_link);
							}
							?>
						</div>
					</nav>
				<?php
						endif;
						wp_reset_postdata();
					else :
				?>
			</div>
		<?php
					endif;
		?>
		</div>
		</div>
	</section>

	<!-- cta banner -->
	<div class="cta-modal-call">
		<section class="footer-cta" data-cta="cta-data">
			<?php get_template_part('template-parts/ats-cta'); ?>
		</section>
	</div>
	<!-- cta banner end -->

	<!-- contact modal box  -->
	<section class="modal-popup" data-contact="contact-show">
		<?php get_template_part('template-parts/ats-contact'); ?>
	</section>
	<!-- contact modal box end -->
</main>

<?php get_footer(); ?>