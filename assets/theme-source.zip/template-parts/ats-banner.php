<?php

$top_page_id = get_option('page_on_front') ? get_option('page_on_front') : 156;


$notice_banners = SCF::get('notice_banners', $top_page_id);
$notice = !empty($notice_banners) ? $notice_banners[0] : null;


$other_banners = SCF::get('other_banners', $top_page_id);
$other = !empty($other_banners) ? $other_banners[0] : null;
?>

<div class="news-banner-box">

    <!-- 1. Notice Banner -->
    <div class="news-banner banner-notice">
        <?php if (!empty($notice['banner_notice_label'])) : ?>
            <div class="card-label">
                <?php echo esc_html($notice['banner_notice_label']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($notice['banner_notice_title'])) : ?>
            <div class="banner-one-ttl">
                <?php echo wp_kses_post(html_entity_decode($notice['banner_notice_title'])); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($notice['banner_notice_desc'])) : ?>
			<div class="banner-one-para">
				<?php 
				$desc = wp_kses_post($notice['banner_notice_desc']);
				$desc = preg_replace('/<p>\s*(<br[^>]*>|&nbsp;|\s)*<\/p>/i', '', $desc);
				echo $desc;
				?>
			</div>
		<?php endif; ?>

        <?php if (!empty($notice['banner_notice_link_text'])) : ?>
            <div class="news-banner-btn-wrp">
                <a href="<?php echo esc_url(!empty($notice['banner_notice_link']) ? home_url($notice['banner_notice_link']) : home_url('/#ikusei-shuro')); ?>" class="news-banner-btn long-txt">
                    <?php echo esc_html($notice['banner_notice_link_text']); ?>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- 2. Other / Food & Drink Banner -->
    <div class="news-banner banner-foodndrink">
        <?php if (!empty($other['banner_label'])) : ?>
            <div class="card-label green">
                <?php echo esc_html($other['banner_label']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($other['banner_title'])) : ?>
            <div class="banner-two-ttl">
                <?php echo wp_kses_post($other['banner_title']); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($other['banner_desc'])) : ?>
            <div class="banner-two-para">
                <?php 
					$desc = wp_kses_post($other['banner_desc']);
					// Remove empty <p> tags that contain only whitespace, <br>, or &nbsp;
					$desc = preg_replace('/<p>\s*(<br[^>]*>|&nbsp;|\s)*<\/p>/i', '', $desc);
					echo $desc;
				?>
            </div>
        <?php endif; ?>

        <div class="fnd-banner-img">
			<?php 
			
			$banner_img_id = !empty($other['banner_image']) ? $other['banner_image'] : (!empty($other['banner_img']) ? $other['banner_img'] : '');

			if (!empty($banner_img_id)) : 
				
				echo wp_get_attachment_image($banner_img_id, 'full', false, array(
					'alt' => !empty($other['banner_label']) ? esc_attr($other['banner_label'] . 'の画像') : '飲食料品製造業の画像'
				));
			else : 
			
			?>
				<picture>
					<source srcset="<?php echo esc_url( get_template_directory_uri() . '/assets/img/food_and_drink_banner.webp' ); ?>" type="image/webp">
					<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/food_and_drink_banner.png' ); ?>" alt="飲食料品製造業の画像">
				</picture>
			<?php endif; ?>
		</div>

        <?php if (!empty($other['banner_btn_text'])) : ?>
            <div class="news-banner-btn-wrp">
                <a href="<?php echo esc_url(!empty($other['banner_btn_link']) ? home_url($other['banner_btn_link']) : home_url('/contact/')); ?>" class="news-banner-btn">
                    <?php echo esc_html($other['banner_btn_text']); ?>
                </a>
            </div>
        <?php endif; ?>
    </div>

</div>