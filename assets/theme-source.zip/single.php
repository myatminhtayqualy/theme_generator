<?php

/**
 * The template for displaying a single news post.
 *
 * @package ats
 */

$ats_news_page       = get_page_by_path('news');
$ats_news_url        = $ats_news_page ? get_permalink($ats_news_page) : home_url('/news/');
get_header();
?>

<main id="main-content" class="news-single-main">
	<?php while (have_posts()) : the_post(); ?>
		<section class="page-intro">
			<div class="container">
				<div class="page-intro-ttl"><span class="page-intro-ttl-eng">News</span>お知らせ</div>
			</div>
		</section>

		<section class="news-single-sec bottom-gradient">
			<div class="container">
                <div class="breadcrumb">
                    <a class="bradcrumb-link" href="<?php echo esc_url( home_url( '/' ) ); ?>">ホーム</a>
                    <a class="bradcrumb-link" href="<?php echo esc_url( $ats_news_url ); ?>">お知らせ</a>
                    <span class="current"><?php echo esc_html( get_the_title() ); ?></span>
                </div>

				<div class="news-single-article">
					<div class="single-post-wrap">

							<div class="single-header">
								<div class="date-blk single-date-blk">
									<p class="date"><?php echo get_the_date('Y.m.d') ?></p>
								</div>
								<h1 class="single-title"><?php echo get_the_title() ?></h1>
							</div>

							<div class="single-content">
								<?php the_content() ?>
							</div>

							<!-- Post Navigation -->
							<div class="post-nav">
								<?php
								// Get the previous and next posts
								$prev_post = get_previous_post();
								$next_post = get_next_post();

								// Display buttons if posts are available
								if ($prev_post): ?>
									<a href="<?php echo get_permalink($prev_post->ID); ?>" class="nav-prev"><span class="nav-arr"></span> 前の記事へ</a>
								<?php endif; ?>

								<?php if ($next_post): ?>
									<a href="<?php echo get_permalink($next_post->ID); ?>" class="nav-next">次の記事へ <span class="nav-arr"></span></a>
								<?php endif; ?>
							</div>

							<div class="single-back-btn-wrap">
								<a class="news-single-back cmn-btn" href="<?php echo esc_url($ats_news_url); ?>">お知らせ一覧に戻る</a>
							</div>
						</div>
				</div>

			</div>
		</section>

		<div class="cta-modal-call">
			<section class="footer-cta" data-cta="cta-data">
				<?php get_template_part('template-parts/ats-cta'); ?>
			</section>
		</div>

		<section class="modal-popup" data-contact="contact-show">
			<?php get_template_part('template-parts/ats-contact'); ?>
		</section>
	<?php endwhile; ?>
</main>

<?php get_footer(); ?>
