<!doctype html>
<html lang="ja">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="description" content="ATS事業協同組合は、育成就労・特定技能・技能実習に対応した監理団体・登録支援機関です。中国・ベトナム・インドネシア・ミャンマーなど7カ国から500名以上の受け入れを支援。制度選びから申請、入国後のフォローまで一貫してサポートします。無料相談受付中。">
	<title>外国人材の受け入れならATS事業協同組合｜育成就労・特定技能・技能実習</title>

	<!-- favicon/webclipicon -->
    <link rel="icon" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/favicon.ico' ); ?>" sizes="any">
	<link rel="icon" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/favicon.svg' ); ?>" type="image/svg+xml">
	<link rel="apple-touch-icon" href="<?php echo esc_url( get_template_directory_uri() . '/assets/img/webclip.png' ); ?>">

	<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() . '/assets/slick/slick.css' ); ?>">
	<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() . '/assets/slick/slick-theme.css' ); ?>">
	<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() . '/assets/css/import.css' ); ?>">
	<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() . '/assets/css/style.css' ); ?>">
	<?php wp_head(); ?>
</head>

<body <?php body_class( $ats_site_body_class ?? '' ); ?>>
<?php wp_body_open(); ?>
<header id="header">
	<div class="header-wrp">
		<div class="header-container">
			<div class="header-flex">
				<h1 class="header-logo">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/common/ats_logo.png' ); ?>" alt="ATS事業協同組合">
					</a>
				</h1>
				<div class="header-right">
					<ul class="header-navi">
						<li><a href="<?php echo esc_url( home_url( '/esd/' ) ); ?>" class="header-nav-link">育成就労</a></li>
						<li><a href="<?php echo esc_url( home_url( '/ssw/' ) ); ?>" class="header-nav-link">特定技能</a></li>
						<li><a href="<?php echo esc_url( home_url( '/tit/' ) ); ?>" class="header-nav-link">技能実習</a></li>
						<li><a href="<?php echo esc_url( home_url( '/about/' ) ); ?>" class="header-nav-link">ATSについて</a></li>
						<li><a href="<?php echo esc_url( home_url( '/news/' ) ); ?>" class="header-nav-link">お知らせ</a></li>
						<li><a href="<?php echo esc_url( home_url( '/faq/' ) ); ?>" class="header-nav-link">よくある質問</a></li>
					</ul>
					<a href="/contact/" class="cmn-btn header-cmn-btn">無料相談する</a>
					<button class="hamburger" type="button" aria-label="メニューを開く">
						<span class="burger-line one"></span>
						<span class="burger-line two"></span>
						<span class="burger-line three"></span>
					</button>
				</div>
			</div>
		</div>
	</div>
	<div class="burger-menu">
		<ul class="burger-navi"></ul>
		<a href="/contact/" class="cmn-btn burger-cmn-btn">無料相談する</a>
	</div>
</header>
