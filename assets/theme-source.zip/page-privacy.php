<?php

/**
 * Template Name: Privacy Policy
 */
$ats_site_body_class = 'privacy-page';
get_header();
?>

<main id="main-content">
	<section class="page-intro">
		<div class="container">
			<h1 class="page-intro-ttl"><span class="page-intro-ttl-eng">PRIVACY POLICY</span>プライバシーポリシー</h1>
		</div>
	</section>
	<div class="container">
        <?php get_template_part('template-parts/ats-breadcrumb'); ?>
    </div>
	<div class="privacy-content bottom-gradient">
		<div class="container">
			<section>
				<h2>個人情報の利用目的</h2>
				<p>当サイトでは、メールでのお問い合わせ、メールマガジンへの登録などの際に、名前、メールアドレス等の個人情報を記載いただく場合がございます。<br>
					これらの個人情報は質問に対する回答や必要な情報を電子メールなどでご連絡する場合に利用するものであり、個人情報をご提供いただく際の目的以外では利用いたしません。</p>
			</section>
			<section>
				<h2>個人情報の第三者への開示</h2>
				<p>当サイトでは、個人情報は適切に管理し、以下に該当する場合を除いて第三者に開示することはありません。</p>
				<ul>
					<li>ご本人の承諾がある場合</li>
					<li>法令等への協力のため、開示が必要となる場合</li>
				</ul>
			</section>
			<section>
				<h2>個人情報の開示、訂正、追加、削除、利用停止</h2>
				<p>ご本人からの個人データの開示、訂正、追加、削除、利用停止のご希望の場合には、ご本人であることを確認させていただいた上、速やかに対応いたします。</p>
			</section>
			<section>
				<h2>アクセス解析ツールについて</h2>
				<p>当サイトでは、Googleによるアクセス解析ツール「Googleアナリティクス」を利用しています。<br>
					このGoogleアナリティクスは、トラフィックデータの収集のためにCookieを使用しています。<br>
					このトラフィックデータは匿名で収集されており、個人を特定するものではありません。<br>
					この機能はCookieを無効にすることで収集を拒否することができますので、お使いのブラウザの設定をご確認ください。</p>
			</section>
			<section>
				<h2>免責事項</h2>
				<p>当サイトからリンクやバナーなどによって他のサイトに移動された場合、移動先サイトで提供される情報、サービス等について一切の責任を負いません。<br>
					当サイトのコンテンツ・情報につきまして、可能な限り正確な情報を掲載するよう努めておりますが、誤情報が入り込んだり、情報が古くなっていることもございます。<br>
					当サイトに掲載された内容によって生じた損害等の一切の責任を負いかねますのであらかじめご了承くださいますようお願いいたします。</p>
			</section>
			<section>
				<h2>プライバシーポリシーの変更について</h2>
				<p>当サイトは、個人情報に関して適用される日本の法令を遵守するとともに、本ポリシーの内容を適宜見直しその改善に努めます。<br>
					修正された最新のプライバシーポリシーは常に本ページにて開示されます。</p>
			</section>
			<p class="privacy-end">以上</p>
		</div>
	</div>

	<!-- cta banner -->
	<div class="cta-modal-call">
		<section class="footer-cta" data-cta="cta-data">
			<?php get_template_part('template-parts/ats-cta'); ?>
		</section>
	</div>
	<!-- cta banner end -->

	<!-- contact modal box  -->
	<section class="modal-popup" data-contact="contact-show">
		<?php get_template_part('template-parts/ats-contact'); ?>
	</section>
	<!-- contact modal box end -->
</main>

<?php get_footer(); ?>