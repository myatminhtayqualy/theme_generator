<?php

/** Template Name: esd */
$ats_site_body_class = 'technical-intern-training-page program-detail-page';
get_header();
?>

<main id="main-content">
	<section class="page-intro">
		<div class="container">
			<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">Employment for Skill Development</span>育成就労</h2>
		</div>
	</section>
	<div class="container">
		<?php get_template_part('template-parts/ats-breadcrumb'); ?>
	</div>
	<section class="info-section program-detail reduce-padding">
		<div class="container">
			<div class="sub-container">

				<h3 class="cmn-ttl cmn-ttl-jp">
					<?php
					$value = SCF::get('esd-cmn-ttl-jp');
					echo esc_html($value);
					?>
				</h3>
				<?php
				$program_image = absint(SCF::get('esd-training-image'));
				$program_image_alt = SCF::get('esd-training-image-alt');
				if ($program_image) {
					echo wp_get_attachment_image($program_image, 'full', false, array('class' => 'training-image', 'alt' => $program_image_alt));
				}
				?>
				<div class="training-intro">
					<?php
					$value = SCF::get('esd-training-intro');
					echo wp_kses_post($value);
					?>
				</div>
			</div>

			<div class="why-cards three_columns">
				<?php
				$about_cards = SCF::get('esd_about_cards');
				$number = 1;

				if (!empty($about_cards)) :
					foreach ($about_cards as $card) :
						$title = $card['esd_about_card_ttl'] ?? '';
						$desc  = $card['esd_about_card_desc'] ?? '';
				?>
						<div class="why-card">
							<div class="why-number">
								<?php echo esc_html(sprintf('%02d', $number)); ?>
							</div>

							<h4 class="why-ttl">
								<?php echo esc_html($title); ?>
							</h4>

							<p class="why-para">
								<?php echo wp_kses_post($desc); ?>
							</p>
						</div>
				<?php
						$number++;
					endforeach;
				endif;
				?>
			</div>

			<div class="prog-sect esd-prog-sect">
				<h3 class="cmn-ttl">
					<p class="cmn-ttl-jp">
						<?php echo esc_html(SCF::get('ats_support_areas_ttl')); ?>
					</p>
				</h3>

				<div class="cmn-para-ttl record-ttl">
					<?php echo wp_kses_post(SCF::get('ats_support_areas_intro')); ?>
				</div>
				<div class="prog-grid">
					<?php
					$support_cards = SCF::get('ats_support_cards');

					if (!empty($support_cards)) :
						foreach ($support_cards as $card) :
							$label = $card['ats_support_card_label'] ?? '';
							$title = $card['ats_support_card_ttl'] ?? '';
							$desc  = $card['ats_support_card_desc'] ?? '';
							$note  = $card['ats_support_card_note'] ?? '';
					?>
							<div class="prog-card">
								<div class="card-label">
									<?php echo esc_html($label); ?>
								</div>

								<h4 class="prog-card-ttl">
									<?php echo esc_html($title); ?>
								</h4>

								<div class="prog-card-para ats-support-para">
									<?php echo wp_kses_post($desc); ?>
								</div>

								<div class="note">
									<?php echo wp_kses_post($note); ?>
								</div>
							</div>
					<?php
						endforeach;
					endif;
					?>
				</div>
			</div>

			<!-- cta banner -->
			<div class="container cta-modal-call">
				<section data-cta="cta-data">
					<?php get_template_part('template-parts/ats-cta'); ?>
				</section>
			</div>
			<!-- cta banner end -->
		</div>
	</section>

	<section class="info-section training-schedule program-detail">
		<section class="prog-sect other-programs">
			<?php 
				$ats_support_ttl = SCF::get('ats_support_sector_ttl');
				$ats_support_intro = SCF::get('ats_support_sector_intro');
			?>
			<div class="container">
				<h3 class="cmn-ttl">
					<p class="cmn-ttl-jp"><?php echo esc_html($ats_support_ttl); ?></p>
				</h3>
				<div class="cmn-para-ttl record-ttl">
					<?php echo wp_kses_post($ats_support_intro); ?>
				</div>

				<div class="sub-container">
					<div class="fl-head">
						<h4 class="tbl-title">
							<?php
								$value = SCF::get('esd-tbl-title');
								echo esc_html($value);
							?>
						</h4>
						<p class="fl-legend">
							<span class="sw"aria-hidden="true"></span>
							<span><em>赤の太字</em>の業務区分は、当組合で受け入れ可能です</span>
						</p>
					</div>

					<ul class="info-block">
						<?php
						$rows = SCF::get('esd-info-block');

						if (!empty($rows)) :
							foreach ($rows as $row) :
								if (empty($row['esd-info-left'])) {
									continue;
								}

								$is_ats_support = $row['is_ats_support'] ?? '';
								$info_class = ($is_ats_support === 'yes') ? ' is-ats' : '';
						?>
								<li class="info-list">
									<div class="info-left<?php echo esc_attr($info_class); ?>">
										<p><?php echo esc_html($row['esd-info-left']); ?></p>
									</div>

									<div class="info-right">
										<div>
											<?php echo wp_kses_post($row['esd-info-right'] ?? ''); ?>
										</div>
									</div>
								</li>
						<?php
							endforeach;
						endif;
						?>
					</ul>

					<?php $experience_note = SCF::get('esd-program-note-experience'); ?>

					<?php if (!empty($experience_note)) : ?>
						<div class="program-note occupation-note">
							<?php echo wp_kses_post($experience_note); ?>
						</div>
					<?php endif; ?>

					<div class="program-note mb0">
						<?php
							$value = SCF::get('esd-program-note');
							echo wp_kses_post($value);
						?>
					</div>
				</div>
			</div>
		</section>
		
		<!-- cta banner -->
		<div class="container cta-modal-call">
			<section class="mb-add mt-add" data-cta="cta-data">
				<?php get_template_part('template-parts/ats-cta'); ?>
			</section>
		</div>
		<!-- cta banner end -->

		<section class="prog-sect other-programs schedule-table">
			<div class="container">
				<div class="sub-container">
					<h3 class="cmn-ttl cmn-ttl-jp">
						<?php
						$value = SCF::get('esd-cmn-ttl-jp-schedule');
						echo esc_html($value);
						?>
					</h3>
					<div class="training-intro">
						<?php
						$value = SCF::get('esd-training-schedule-intro');
						echo wp_kses_post($value);
						?>
					</div>

					<div class="training-schedule-group">
						<h4 class="tbl-title">
							<?php
							$value = SCF::get('esd-tbl-title-phase-one');
							echo esc_html($value);
							?>
						</h4>
						<ul class="info-block">
							<?php
							$rows = SCF::get('esd-info-block-phase-one');
							if (! empty($rows)) :
								foreach ($rows as $row) :
									if (empty($row['esd-info-left-phase-one'])) {
										continue;
									}
							?>
									<li class="info-list">
										<div class="info-left">
											<p><?php echo esc_html($row['esd-info-left-phase-one']); ?></p>
										</div>
										<div class="info-right">
											<div><?php echo wp_kses_post($row['esd-info-right-phase-one'] ?? ''); ?></div>
										</div>
									</li>
							<?php
								endforeach;
							endif;
							?>
						</ul>
					</div>

					<div class="training-schedule-group">
						<h4 class="tbl-title">
							<?php
							$value = SCF::get('esd-tbl-title-phase-two');
							echo esc_html($value);
							?>
						</h4>
						<ul class="info-block">
							<?php
							$rows = SCF::get('esd-info-block-phase-two');
							if (! empty($rows)) :
								foreach ($rows as $row) :
									if (empty($row['esd-info-left-phase-two'])) {
										continue;
									}
							?>
									<li class="info-list">
										<div class="info-left">
											<p><?php echo esc_html($row['esd-info-left-phase-two']); ?></p>
										</div>
										<div class="info-right">
											<div><?php echo wp_kses_post($row['esd-info-right-phase-two'] ?? ''); ?></div>
										</div>
									</li>
							<?php
								endforeach;
							endif;
							?>
						</ul>
						<div class="program-note">
							<?php
							$value = SCF::get('esd-program-note-schedule');
							echo wp_kses_post($value);
							?>
						</div>

					</div>
				</div>
			</div>
		</section>

		<!-- other programs  -->
		
		<?php get_template_part('template-parts/other-programs'); ?>

		<!-- other programs  -->
	</section>


	<!-- cta banner -->
	<div class="cta-modal-call">
		<section class="footer-cta" data-cta="cta-data"><?php get_template_part('template-parts/ats-cta'); ?></section>
	</div>
	<!-- cta banner end -->

	<!-- contact modal box  -->
	<section class="modal-popup" data-contact="contact-show"><?php get_template_part('template-parts/ats-contact'); ?>
	</section>
	<!-- contact modal box end -->
</main>
<?php get_footer(); ?>