<div class="cta">
	<div class="cta-txt-box">
		<p class="cta-txt mb5-sp">「自分の会社に合っている制度を知りたい」</p>
		<p class="cta-txt">「外国人材を採用したいが、<br class="sp">何から始めればいいかわからない」</p>
		<strong class="cta-ttl">まずは気軽に<br class="sp">ご相談ください！</strong>
		<small class="cta-small">ATS事業協同組合が制度のご説明から<br class="sp">サポートいたします。</small>
	</div>
	<a href="/contact/" class="cmn-btn cta-btn">無料相談を申し込む</a>
</div>
