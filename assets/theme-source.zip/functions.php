<?php

/**
 * ats functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package ats
 */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function ats_setup()
{
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on ats, use a find and replace
		* to change 'ats' to the name of your theme in all the template files.
		*/
	load_theme_textdomain('ats', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support('post-thumbnails');

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);
}
add_action('after_setup_theme', 'ats_setup');

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function ats_widgets_init()
{
	register_sidebar(
		array(
			'name'          => esc_html__('Sidebar', 'ats'),
			'id'            => 'sidebar-1',
			'description'   => esc_html__('Add widgets here.', 'ats'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action('widgets_init', 'ats_widgets_init');

function ats_static_site_body_class( $classes ) {
	if ( ! empty( $GLOBALS['ats_site_body_class'] ) ) {
		$classes[] = $GLOBALS['ats_site_body_class'];
	}

	return $classes;
}
add_filter('body_class', 'ats_static_site_body_class');

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Customize TinyMCE Color Palette and move Text Color button to the end of Row 1 
 * for Classic Editor and Smart Custom Fields (SCF)
 * Customize TinyMCE Color Palette and move Text Color button to the end of Row 1 
 * for Classic Editor and Smart Custom Fields (SCF)
 */
function fix_scf_tinymce_color_palette() {
    ?>
    <script type="text/javascript">
    (function($) {
        // Define custom color palette (Hex, Label)
        var customColors = [
            '00BFC9', 'Main Color',
            '003B7D', 'Dark Blue',
            '333333', 'Dark Gray',
            '666666', 'Gray',
            '000000', 'Black',
            'FFFFFF', 'White',
			'FF0000', 'Red',
        ];

        $(document).on('tinymce-editor-setup', function(event, editor) {
            
            // 1. Move 'forecolor' button to the end of Row 1
            if (editor.settings.toolbar1) {
                // Remove existing forecolor button if present, then append it to the end
                var tb1 = editor.settings.toolbar1.replace(/forecolor,?/g, '').replace(/,+$/, '').trim();
                editor.settings.toolbar1 = tb1 + ',forecolor';
            }

            // 2. Remove default 'forecolor' button from Row 2
            if (editor.settings.toolbar2) {
                editor.settings.toolbar2 = editor.settings.toolbar2.replace(/forecolor,?/g, '').replace(/,+$/, '').trim();
            }

            // 3. Apply custom color palette and grid layout settings
            editor.settings.textcolor_map  = customColors;
            editor.settings.color_map      = customColors;
            editor.settings.textcolor_cols = 6;
            editor.settings.textcolor_rows = 2;
            editor.settings.custom_colors  = 'true'; // Disable custom color picker
        });
    })(jQuery);
    </script>
    <?php
}
add_action('admin_footer', 'fix_scf_tinymce_color_palette', 99);


// Custom validation for furigana fields in Contact Form 7
add_filter( 'wpcf7_validate_text*', 'custom_furigana_validation_filter', 20, 2 );

function custom_furigana_validation_filter( $result,$tag ) {
    $tag = new WPCF7_FormTag($tag );
    $name =$tag->name;


    if ( 'furisurname' === $name || 'furigivenname' === $name ) {$value = isset( $_POST[$name] ) ? trim( sanitize_text_field( wp_unslash( $_POST[$name] ) ) ) : '';

        if ( ! empty( $value ) && ! preg_match( '/^[\x{3040}-\x{309F}\x{30A0}-\x{30FF}\x{3000}\s]+$/u', $value ) ) {
            $result->invalidate($tag, 'ひらがな、またはカタカナで入力してください。' );
        }
    }

    return $result;
}


// Custom validation for confirm email fields in Contact Form 7
add_filter( 'wpcf7_validate_email*', 'custom_confirm_email_validation_filter', 20, 2 );

function custom_confirm_email_validation_filter( $result, $tag ) {
    $tag = new WPCF7_FormTag( $tag );
    $name = $tag->name;

    if ( 'confirm_email-address' === $name ) {
        $email = isset( $_POST['email-address'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['email-address'] ) ) ) : '';
        $confirm_email = isset( $_POST['confirm_email-address'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['confirm_email-address'] ) ) ) : '';

        if ( $email !== $confirm_email ) {
            $result->invalidate( $tag, 'メールアドレスが一致していません。もう一度確認してください。' );
        }
    }

    return $result;
}