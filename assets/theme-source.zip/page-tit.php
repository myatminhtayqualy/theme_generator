<?php
/** Template Name: tit */
$ats_site_body_class = 'technical-intern-training-page';
get_header();
?>

<main id="main-content">
	<section class="page-intro">
		<div class="container">
			<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">Technical Intern Training</span>技能実習</h2>
		</div>
	</section>
	<div class="container">
        <?php get_template_part('template-parts/ats-breadcrumb'); ?>
    </div>
	<section class="info-section" aria-labelledby="training-occupations-title">
		<div class="container">
			<div class="sub-container">
				<h3 class="cmn-ttl cmn-ttl-jp" id="training-occupations-title">
					<?php
					$value = SCF::get( 'tit-cmn-ttl-jp' );
					echo esc_html( $value );
					?>
				</h3>
				<?php
				$program_image = absint( SCF::get( 'tit-training-image' ) );
				$program_image_alt = SCF::get( 'tit-training-image-alt' );
				if ( $program_image ) {
					echo wp_get_attachment_image( $program_image, 'full', false, array( 'class' => 'training-image', 'alt' => $program_image_alt ) );
				}
				?>
				<div class="training-intro">
					<?php
					$value = SCF::get( 'tit-training-intro' );
					echo wp_kses_post( $value );
					?>
				</div>
				<h4 class="tbl-title">
					<?php
					$value = SCF::get( 'tit-tbl-title' );
					echo esc_html( $value );
					?>
				</h4>
				<ul class="info-block">
					<?php
					$rows = SCF::get( 'tit-info-block' );
					if ( ! empty( $rows ) ) :
						foreach ( $rows as $row ) :
							if ( empty( $row['tit-info-left'] ) ) {
								continue;
							}
							?>
							<li class="info-list">
								<div class="info-left">
									<p><?php echo esc_html( $row['tit-info-left'] ); ?></p>
								</div>
								<div class="info-right">
									<div><?php echo wp_kses_post( $row['tit-info-right'] ?? '' ); ?></div>
								</div>
							</li>
							<?php
						endforeach;
					endif;
					?>
				</ul>
                <?php $experience_note = SCF::get( 'tit-program-note-experience' ); ?>
                <?php if ( ! empty( $experience_note ) ) : ?>
                    <div class="program-note occupation-note">
                        <?php echo wp_kses_post( $experience_note ); ?>
                    </div>
                <?php endif; ?>
			</div>
		</div>
	</section>

	<section class="info-section training-schedule" aria-labelledby="training-schedule-title">
		<div class="container">
			<div class="sub-container">
				<h3 class="cmn-ttl cmn-ttl-jp" id="training-schedule-title">
					<?php
					$value = SCF::get( 'tit-cmn-ttl-jp-schedule' );
					echo esc_html( $value );
					?>
				</h3>
				<div class="training-intro">
					<?php
					$value = SCF::get( 'tit-training-schedule-intro' );
					echo wp_kses_post( $value );
					?>
				</div>
				<div class="training-schedule-group">

					<h4 class="tbl-title">
						<?php
						$value = SCF::get( 'tit-tbl-title-phase-one' );
						echo esc_html( $value );
						?>
					</h4>
					<ol class="info-block">
						<?php
						$rows = SCF::get( 'tit-info-block-phase-one' );
						if ( ! empty( $rows ) ) :
							foreach ( $rows as $row ) :
								if ( empty( $row['tit-info-left-phase-one'] ) ) {
									continue;
								}
								?>
								<li class="info-list">
									<div class="info-left">
										<p><?php echo esc_html( $row['tit-info-left-phase-one'] ); ?></p>
									</div>
									<div class="info-right">
										<div><?php echo wp_kses_post( $row['tit-info-right-phase-one'] ?? '' ); ?></div>
									</div>
								</li>
								<?php
							endforeach;
						endif;
						?>
					</ol>
				</div>
				<div class="training-schedule-group">
					<h4 class="tbl-title" id="training-schedule-phase-2">
						<?php
						$value = SCF::get( 'tit-tbl-title-phase-two' );
						echo esc_html( $value );
						?>
					</h4>
					<ol class="info-block" aria-labelledby="training-schedule-phase-2">
						<?php
						$rows = SCF::get( 'tit-info-block-phase-two' );
						if ( ! empty( $rows ) ) :
							foreach ( $rows as $row ) :
								if ( empty( $row['tit-info-left-phase-two'] ) ) {
									continue;
								}
								?>
								<li class="info-list">
									<div class="info-left">
										<p><?php echo esc_html( $row['tit-info-left-phase-two'] ); ?></p>
									</div>
									<div class="info-right">
										<div><?php echo wp_kses_post( $row['tit-info-right-phase-two'] ?? '' ); ?></div>
									</div>
								</li>
								<?php
							endforeach;
						endif;
						?>
					</ol>
				</div>
			</div>
		</div>

		<!-- other programs  -->
		
		<?php get_template_part('template-parts/other-programs'); ?>

		<!-- other programs  -->
	</section>

	<!-- cta banner -->
	<div class="cta-modal-call">
		<section class="footer-cta" data-cta="cta-data">
			<?php get_template_part( 'template-parts/ats-cta' ); ?>
		</section>
	</div>
	<!-- cta banner end -->

	<!-- contact modal box  -->
	<section class="modal-popup" data-contact="contact-show">
		<?php get_template_part( 'template-parts/ats-contact' ); ?>
	</section>
	<!-- contact modal box end -->
</main>

<?php get_footer(); ?>
