<?php
/** Template Name: Thanks */
get_header();
?>

<main id="main-content">
	<section class="page-intro">
		<div class="container">
			<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">Thanks</span>お問い合わせ</h2>
		</div>
	</section>
	<div class="container">
        <?php get_template_part('template-parts/ats-breadcrumb'); ?>
    </div>
	<section class="thank-section bottom-gradient" aria-label="よくあるご質問一覧">
		<div class="container">
			<div class="sub-container">
              <h3 class="thank-ttl">お問い合わせフォームの送信を完了致しました。</h3>
              <p class="thank-para">この度はお問い合わせいただきまして誠にありがとうございます。<br>ご入力頂いたメールアドレス宛へ、ご確認メールをお送りしておりますのでご確認ください。<br>内容を確認次第、担当者より折返しご連絡させていただきます。今しばらくお待ちくださいませ。</p>
              <a href="<?php echo esc_url(home_url('/')); ?>" class="cmn-btn comfirm-btn"><span class="consult-txt view-txt red-view-txt">TOPページに戻る</span></a>
            </div>
		</div>
	</section>
</main>
<?php get_footer(); ?>