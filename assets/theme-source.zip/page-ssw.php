<?php
/** Template Name: ssw */
$ats_site_body_class = 'technical-intern-training-page program-detail-page';
get_header();
?>

<main id="main-content">
	<section class="page-intro">
		<div class="container">
			<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">Specified Skilled Worker</span>特定技能</h2>
		</div>
	</section>
	<div class="container">
        <?php get_template_part('template-parts/ats-breadcrumb'); ?>
    </div>
	<section class="info-section program-detail">
		<div class="container">
			<div class="sub-container">

				<h3 class="cmn-ttl cmn-ttl-jp">
					<?php
					$value = SCF::get( 'ssw-cmn-ttl-jp' );
					echo esc_html( $value );
					?>
				</h3>
				<?php
				$program_image = absint( SCF::get( 'ssw-training-image' ) );
				$program_image_alt = SCF::get( 'ssw-training-image-alt' );
				if ( $program_image ) {
					echo wp_get_attachment_image( $program_image, 'full', false, array( 'class' => 'training-image', 'alt' => $program_image_alt ) );
				}
				?>
				<div class="training-intro">
					<?php
					$value = SCF::get( 'ssw-training-intro' );
					echo wp_kses_post( $value );
					?>
				</div>

				<h4 class="tbl-title">
					<?php
					$value = SCF::get( 'ssw-tbl-title' );
					echo esc_html( $value );
					?>
				</h4>
				<ul class="info-block">
					<?php
					$rows = SCF::get( 'ssw-info-block' );
					if ( ! empty( $rows ) ) :
						foreach ( $rows as $row ) :
							if ( empty( $row['ssw-info-left'] ) ) {
								continue;
							}
							?>
							<li class="info-list">
								<div class="info-left">
									<p><?php echo esc_html( $row['ssw-info-left'] ); ?></p>
								</div>
								<div class="info-right">
									<div><?php echo wp_kses_post( $row['ssw-info-right'] ?? '' ); ?></div>
								</div>
							</li>
							<?php
						endforeach;
					endif;
					?>
				</ul>
                <?php $experience_note = SCF::get( 'ssw-program-note-experience' ); ?>
                <?php if ( ! empty( $experience_note ) ) : ?>
                    <div class="program-note occupation-note">
                        <?php echo wp_kses_post( $experience_note ); ?>
                    </div>
                <?php endif; ?>
                <div class="program-note">
                    <?php
                    $value = SCF::get( 'ssw-program-note' );
                    echo wp_kses_post( $value );
                    ?>
                </div>

				<div class="program-comparison-section">
				<h3 class="cmn-ttl cmn-ttl-jp">
					<?php
					$value = SCF::get( 'ssw-cmn-ttl-jp-comparison' );
					echo esc_html( $value );
					?>
				</h3>
				<div class="program-comparison">
					<table class="cmp">
						<thead>
							<tr>
								<th scope="col">
									<?php
									$value = SCF::get( 'ssw-cmp-item-header' );
									echo esc_html( $value );
									?>
								</th>
								<th scope="col">
									<?php
									$value = SCF::get( 'ssw-cmp-one-header' );
									echo esc_html( $value );
									?>
								</th>
								<th scope="col">
									<?php
									$value = SCF::get( 'ssw-cmp-two-header' );
									echo esc_html( $value );
									?>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$comparisons = SCF::get( 'ssw-cmp' );
							if ( ! empty( $comparisons ) ) :
								foreach ( $comparisons as $comparison ) :
									if ( empty( $comparison['ssw-cmp-item'] ) ) {
										continue;
									}
									?>
									<tr>
										<th scope="row"><?php echo esc_html( $comparison['ssw-cmp-item'] ); ?></th>
										<td><?php echo wp_kses_post( $comparison['ssw-cmp-one'] ?? '' ); ?></td>
										<td><?php echo wp_kses_post( $comparison['ssw-cmp-two'] ?? '' ); ?></td>
									</tr>
									<?php
								endforeach;
							endif;
							?>
						</tbody>
					</table>
				</div>

				</div>
			</div>
		</div>
	</section>

	<section class="info-section training-schedule program-detail">
		<div class="container">
			<div class="sub-container">
				<h3 class="cmn-ttl cmn-ttl-jp">
					<?php
					$value = SCF::get( 'ssw-cmn-ttl-jp-schedule' );
					echo esc_html( $value );
					?>
				</h3>
				<div class="training-intro">
					<?php
					$value = SCF::get( 'ssw-training-schedule-intro' );
					echo wp_kses_post( $value );
					?>
				</div>

				<div class="training-schedule-group">
				<h4 class="tbl-title">
					<?php
					$value = SCF::get( 'ssw-tbl-title-phase-one' );
					echo esc_html( $value );
					?>
				</h4>
				<ul class="info-block">
					<?php
					$rows = SCF::get( 'ssw-info-block-phase-one' );
					if ( ! empty( $rows ) ) :
						foreach ( $rows as $row ) :
							if ( empty( $row['ssw-info-left-phase-one'] ) ) {
								continue;
							}
							?>
							<li class="info-list">
								<div class="info-left">
									<p><?php echo esc_html( $row['ssw-info-left-phase-one'] ); ?></p>
								</div>
								<div class="info-right">
									<div><?php echo wp_kses_post( $row['ssw-info-right-phase-one'] ?? '' ); ?></div>
								</div>
							</li>
							<?php
						endforeach;
					endif;
					?>
				</ul>
				<div class="program-note">
					<?php
					$value = SCF::get( 'ssw-program-note-schedule' );
					echo wp_kses_post( $value );
					?>
				</div>

				</div>
				<div class="training-schedule-group">
				<h4 class="tbl-title">
					<?php
					$value = SCF::get( 'ssw-tbl-title-phase-two' );
					echo esc_html( $value );
					?>
				</h4>
				<ul class="info-block">
					<?php
					$rows = SCF::get( 'ssw-info-block-phase-two' );
					if ( ! empty( $rows ) ) :
						foreach ( $rows as $row ) :
							if ( empty( $row['ssw-info-left-phase-two'] ) ) {
								continue;
							}
							?>
							<li class="info-list">
								<div class="info-left">
									<p><?php echo esc_html( $row['ssw-info-left-phase-two'] ); ?></p>
								</div>
								<div class="info-right">
									<div><?php echo wp_kses_post( $row['ssw-info-right-phase-two'] ?? '' ); ?></div>
								</div>
							</li>
							<?php
						endforeach;
					endif;
					?>
				</ul>

				</div>
			</div>
		</div>

		<!-- other programs  -->
		
		<?php get_template_part('template-parts/other-programs'); ?>

		<!-- other programs  -->
	</section>
	<!-- cta banner -->
	<div class="cta-modal-call">
		<section class="footer-cta" data-cta="cta-data"><?php get_template_part( 'template-parts/ats-cta' ); ?></section>
	</div>
	<!-- cta banner end -->

	<!-- contact modal box  -->
	<section class="modal-popup" data-contact="contact-show"><?php get_template_part( 'template-parts/ats-contact' ); ?>
	</section>
	<!-- contact modal box end -->
	</section>
	<footer>
		<section id="footer"></section>
	</footer>

	<!-- js -->
	<script src="/assets/js/jquery-3.7.1.min.js"></script>
	<script src="/assets/js/jquery.matchHeight.js"></script>
	<script src="/assets/slick/slick.min.js"></script>
	<script src="/assets/js/common.js"></script>
	<!-- calling header, footer & templateparts -->
	<script>
		$(window).on('load', function () {

			$("#header").load("/inc/header.html", function () {
				// Header has finished loading
				initHeader();
			});

			$("#footer").load("/inc/footer.html");

			$('[data-cta="cta-data"]').load("/inc/ats-cta.html");

		});
	</script>
</main>
<?php get_footer(); ?>
