(function ($) {
// header start
function initHeader() {
    const $burger = $('.hamburger');
    const $topHeader = $('.top-body .header-wrp');

    if ($burger.length) {
        $burger.on('click', () => {
            $burger.toggleClass('cross');
            $('body').toggleClass('locked-scroll');
            $('.burger-menu').toggleClass('show');
            $('.header-wrp').toggleClass('full-opac');

            if ($('.burger-menu').hasClass('show')) {
                $('.burger-navi').html($('.header-navi').html());
            } else {
                $('.burger-navi').html('');
            }
        });
        
        $('.burger-menu').on('click', '.header-nav-link', () => {
            $burger.toggleClass('cross');
            $('body').toggleClass('locked-scroll');
            $('.burger-menu').toggleClass('show');
            $('.header-wrp').toggleClass('full-opac');
        })
    }

    if ($topHeader.length) {
        $(window).on('scroll', () => {
            $topHeader.toggleClass('white-bg', window.scrollY > 40);
        });
    }
}

initHeader();
// header end

// Your JavaScript code goes here
document.addEventListener("DOMContentLoaded", () => {});

// Your jQuery code goes here
$(function () {
    $(window).on('load resize', () => {
        if (window.innerWidth >= 581) {
            $(".prog-card-ttl").matchHeight();
            $(".prog-card-para").matchHeight();
            $(".prog-card-para.ats-support-para").matchHeight();
			$(".note").matchHeight();
        }
    });

	$(".why-card").matchHeight();
	$(".why-ttl").matchHeight();
	$(".prog-card-para.ats-support-para").matchHeight();
	$(".note").matchHeight();
    $(".countries-card-ttl").matchHeight({ byRow: false });

    // slider
    $('.voice-slider').slick({
		arrows: true,
		dots: false,
		infinite: true,
        variableWidth: false,
		slidesToScroll: 1,
		slidesToShow: 2,
		centerMode: true,
        centerPadding: '0px',
		swipeToSlide: true,
		responsive: [
			{ breakpoint: 1200, settings: { variableWidth: false, slidesToShow: 2 } },
			{ breakpoint: 900, settings: { variableWidth: false, slidesToShow: 1 } }
		]
	});

    
    // FAQ section start
    $(function () {
    $('.enri-faq-q').on('click', function () {
        const $answer = $(this).next('.enri-faq-ans');

        $(this).toggleClass('active');
        $answer.stop(true, true).slideToggle(250);
    });
    });
    // FAQ section end

    // contact modal box

    const $modalPopup = $('[data-contact="contact-show"]');

    function openModal(stableParent) {
        stableParent.on('click', '[data-contact="fetch-contact"]', function () {
            $modalPopup.addClass('is-open').find('.overlay').attr('aria-hidden', 'false');
            $('body').addClass('locked-scroll');
        });

        // Prevent clicks inside the popup from closing it
        $modalPopup.on('click', '.popup', function (event) {
            event.stopPropagation();
        });

        // Close modal when clicking the overlay
        $modalPopup.on('click', '.overlay', function () {
            $modalPopup.removeClass('is-open').find('.overlay').attr('aria-hidden', 'true');
            $('body').removeClass('locked-scroll');
        });

        // Close modal when clicking the exit button
        $modalPopup.on('click', '.exit-popup', function () {
            $modalPopup.removeClass('is-open').find('.overlay').attr('aria-hidden', 'true');
            $('body').removeClass('locked-scroll');
        });
    }

    openModal($('#header, .mv-content-blk, .cta-modal-call, #banner'));
    
    // contact modal box end

});
})(jQuery);
