<?php
/**
 * Template Name: Intern
 */
$ats_site_body_class = 'technical-intern-training-page';
get_header();
?>

<main id="main-content">
        <section class="page-intro">
			<div class="container">
				<h2 class="page-intro-ttl"><span class="page-intro-ttl-eng">Technical Intern Training</span>技能実習</h2>
			</div>
		</section>
        <section class="info-section" aria-labelledby="training-occupations-title">
            <div class="container">
                <div class="sub-container">
                    <h3 class="cmn-ttl cmn-ttl-jp" id="training-occupations-title">技能実習を実施できる職種・作業</h3>
                    <img class="training-image" src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/tech_it_img.png' ); ?>" alt="技能実習を実施できる職種・作業の画像">
                    <p class="training-intro">技能実習を実施できる職種・作業について、詳細は以下の通りになります。</p>
                    <h4 class="tbl-title">技能実習を実施できる職種・作業一覧</h4>
                    <ul class="info-block">
                        <li class="info-list">
                            <div class="info-left">
                                <p>農業関係</p>
                            </div>
                            <div class="info-right">
                                <p>耕種農業、畜産農業、肉牛の飼育</p>
                            </div>
                        </li>
                        <li class="info-list">
                            <div class="info-left">
                                <p>建設関係</p>
                            </div>
                            <div class="info-right pd-add">
                                <p>建築大工、型枠施工、鉄筋施工、とび、石材施工、タイル張り、かわらぶき、左官、配管、内装仕上げ施工、サッシ施工、防水施工、表装</p>
                            </div>
                        </li>
                        <li class="info-list">
                            <div class="info-left">
                                <p>食品製造関係</p>
                            </div>
                            <div class="info-right">
                                <p>加熱性水産加工食品製造業、ハム・ソーセージ・ベーコン製造、そう菜製造業</p>
                            </div>
                        </li>
                        <li class="info-list">
                            <div class="info-left">
                                <p>機械・金属関係</p>
                            </div>
                            <div class="info-right">
                                <p>機械加工、鉄工、機械検査</p>
                            </div>
                        </li>
                        <li class="info-list">
                            <div class="info-left">
                                <p>その他</p>
                            </div>
                            <div class="info-right">
                                <p>家具製作、プラスチック成形、強化プラスチック成形、塗装、溶接、工業包装、リネンサプライ</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>

        <section class="info-section training-schedule" aria-labelledby="training-schedule-title">
            <div class="container">
                <div class="sub-container">
                    <h3 class="cmn-ttl cmn-ttl-jp" id="training-schedule-title">実習生受入スケジュール</h3>
                    <p class="training-intro">技能実習生受入の流れは下記をご覧ください。</p>
                    <div class="training-schedule-group">

                        <h4 class="tbl-title">「申込」～「配属」まで</h4>
                        <ol class="info-block">
                            <li class="info-list">
                                <div class="info-left"><p>①お問合せ ～ ご相談</p></div>
                                <div class="info-right"><p>まずはお問合せ下さい。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>②お申込み ～ 求人</p></div>
                                <div class="info-right"><p>お申込み受付後すぐに、現地へ求人依頼します。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>③現地面接</p></div>
                                <div class="info-right"><p>【②より約1か月後】<br>現地で面接を行います。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>④現地での日本語学習</p></div>
                                <div class="info-right"><p>技能実習生が決定後、現地講習を開始します。<br>※約3~4か月</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑤技能実習計画の作成</p></div>
                                <div class="info-right"><p>④の間に技能実習計画を作成していただきます。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑥申請</p></div>
                                <div class="info-right"><p>④の間に下記を行います。<br>・外国人技能実習機構へ技能実習計画認定申請<br>・在留管理局へ在留資格認定証明書発行申請</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑦現地の状況確認</p></div>
                                <div class="info-right"><p>実習生の現地の状況をレポートいたします。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑧送出国でのビザ申請</p></div>
                                <div class="info-right"><p>出国ビザの発給申請を行います。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑨入国</p></div>
                                <div class="info-right"><p>現地日本語学習を終え、日本に上陸します。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑩集合講習</p></div>
                                <div class="info-right"><p>日本語及び日本文化・慣習等の講習をします。<br>・日本語<br>・本邦での生活一般に関する知識<br>・出入国又は労働に関する法令の規定に違反していることを知った時の対応方法、その他技能実習生の法的保護に必要な方法<br>・その他、本邦での円滑な技能等の習得に資する知識</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑪配属、技能実習開始</p></div>
                                <div class="info-right"><p>1か月の講習を経て、企業様に配属となります。</p></div>
                            </li>
                        </ol>
                    </div>
                    <div class="training-schedule-group">
                        <h4 class="tbl-title" id="training-schedule-phase-2">「配属」～「2号実習」まで</h4>
                        <ol class="info-block" aria-labelledby="training-schedule-phase-2">
                            <li class="info-list">
                                <div class="info-left"><p>①各社にて技能実習</p></div>
                                <div class="info-right"><p>約11ヶ月、技能実習日程に沿って技能を学びます。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>②技能検定</p></div>
                                <div class="info-right"><p>入国1年目の後半に、技能検定（基礎2級）を受験します。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>③申請</p></div>
                                <div class="info-right"><p>下記申請を行います。<br>・外国人技能実習機構へ技能実習計画認定申請<br>・在留管理局へ在留資格変更申請（技能実習1号→2号）</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>④期間更新</p></div>
                                <div class="info-right"><p>入国2年目の後半に、在留管理局へ期間更新申請を行います。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑤技能検定</p></div>
                                <div class="info-right"><p>入国3年目の期間中に、技能検定（随時3級）を受験します。</p></div>
                            </li>
                            <li class="info-list">
                                <div class="info-left"><p>⑥帰国</p></div>
                                <div class="info-right"><p>3年間の日本での実習を修了し帰国します。</p></div>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>

        <!-- cta banner -->
        <div class="cta-modal-call">
             <section class="footer-cta" data-cta="cta-data">
<?php get_template_part( 'template-parts/ats-cta' ); ?>
</section>
        </div>
        <!-- cta banner end -->

        <!-- contact modal box  -->
        <section class="modal-popup" data-contact="contact-show">
<?php get_template_part( 'template-parts/ats-contact' ); ?>
</section>
        <!-- contact modal box end -->
    </main>

<?php get_footer(); ?>
